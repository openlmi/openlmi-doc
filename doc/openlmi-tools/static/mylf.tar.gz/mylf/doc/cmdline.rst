LMI command line reference
==========================
..
    Write some description here.

.. include:: cmdline.generated
