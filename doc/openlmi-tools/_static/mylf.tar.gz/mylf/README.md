MyLF
====
A complete source for step-by-step tutorial hosted on
https://fedorahosted.org/openlmi/wiki/scripts/tutorial.

It provides similar functionality as `logicalfile` script and operates upon the
same set of providers.
